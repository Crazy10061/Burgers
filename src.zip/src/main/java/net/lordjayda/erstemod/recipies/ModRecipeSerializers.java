package net.lordjayda.erstemod.recipies;

import net.lordjayda.erstemod.Erstemod;
import net.minecraft.world.item.crafting.RecipeSerializer;

public class ModRecipeSerializers {

    public static RecipeSerializer<?> ASSEMBLER;

    public static void registerRecipeSerializers() {
        Erstemod.LOGGER.info("Registering Recipe Serializers");
    }
}