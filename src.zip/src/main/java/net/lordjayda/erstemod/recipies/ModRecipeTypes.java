package net.lordjayda.erstemod.recipies;

import net.lordjayda.erstemod.Erstemod;
import net.lordjayda.erstemod.recipies.custom.AssemblerRecipe;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.crafting.RecipeType;

public class ModRecipeTypes {

    public static final RecipeType<AssemblerRecipe> ASSEMBLER =
            Registry.register(
                    BuiltInRegistries.RECIPE_TYPE,
                    Identifier.fromNamespaceAndPath(Erstemod.MOD_ID, "assembler"),
                    new RecipeType<>() {
                        @Override
                        public String toString() {
                            return "assembler";
                        }
                    });

    public static void registerRecipeTypes() {
        Erstemod.LOGGER.info("Registering Recipe Types");
    }
}