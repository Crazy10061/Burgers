package net.lordjayda.erstemod.recipies.custom;

import net.lordjayda.erstemod.recipies.ModRecipeSerializers;
import net.lordjayda.erstemod.recipies.ModRecipeTypes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.NonNull;

public class AssemblerRecipe implements Recipe<AssemblerRecipeInput> {

    private final ItemStack result;

    public AssemblerRecipe(ItemStack result) {
        this.result = result;
    }

    @Override
    public boolean matches(AssemblerRecipeInput input, Level level) {
        return false;
    }

    @Override
    public ItemStack assemble(AssemblerRecipeInput input) {
        return result.copy();
    }

    @Override
    public boolean showNotification() {
        return false;
    }

    @Override
    public String group() {
        return "assembler";
    }

    @Override
    public RecipeSerializer<? extends Recipe<AssemblerRecipeInput>> getSerializer() {
        return (RecipeSerializer<? extends Recipe<AssemblerRecipeInput>>) ModRecipeSerializers.ASSEMBLER;
    }

    @Override
    public RecipeType<? extends Recipe<AssemblerRecipeInput>> getType() {
        return ModRecipeTypes.ASSEMBLER;
    }

    @Override
    public PlacementInfo placementInfo() {
        return PlacementInfo.NOT_PLACEABLE;
    }

    @Override
    public RecipeBookCategory recipeBookCategory() {
        return null;
    }
}